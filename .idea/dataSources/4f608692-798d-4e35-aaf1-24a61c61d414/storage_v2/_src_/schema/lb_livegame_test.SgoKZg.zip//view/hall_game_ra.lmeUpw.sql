create view hall_game_ra as
  select distinct
    `lb_livegame_test`.`game_server_info`.`room_type` AS `hall_id`,
    `lb_livegame_test`.`game_server_info`.`game_id`   AS `game_id`
  from `lb_livegame_test`.`game_server_info`
  where (`lb_livegame_test`.`game_server_info`.`enable` = 1);

