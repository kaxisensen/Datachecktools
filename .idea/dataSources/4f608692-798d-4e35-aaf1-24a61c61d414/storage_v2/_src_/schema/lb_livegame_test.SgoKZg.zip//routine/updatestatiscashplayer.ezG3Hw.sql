create procedure UpdateStatisCashPlayer(IN BetScore double, IN BetCount int, IN WinScore double, IN ymd date,
                                        IN UserID   int unsigned, IN AgentID int unsigned, IN HallID int unsigned,
                                        IN Account  varchar(32))
  BEGIN
DECLARE _id INT UNSIGNED;
DECLARE _WinCountLast INT UNSIGNED;
DECLARE _WinCountCur INT UNSIGNED;
IF WinScore > 0 THEN
INSERT INTO statis_cash_player(total_bet_score, total_bet_count, total_win_score, add_date, day_year, day_month, day_day, agent_id, hall_id, user_id, user_name, win_count_last, win_count_cur, totalwinnums) VALUES(BetScore,BetCount,WinScore,ymd,YEAR(ymd),MONTH(ymd),DAY(ymd),AgentID,HallID,UserID,Account,1,1,1) ON DUPLICATE KEY UPDATE total_bet_score = total_bet_score + BetScore, total_bet_count = total_bet_count + BetCount, total_win_score = total_win_score + WinScore, win_count_cur = win_count_cur + 1,totalwinnums = totalwinnums + 1;
SELECT id,win_count_last,win_count_cur INTO _id, _WinCountLast,_WinCountCur FROM statis_cash_player WHERE user_id = UserID AND hall_id = HallID AND add_date = ymd;
IF _WinCountCur > _WinCountLast THEN
UPDATE statis_cash_player SET win_count_last = _WinCountCur WHERE id=_id; 
END IF;
ELSE
INSERT INTO statis_cash_player(total_bet_score, total_bet_count, total_win_score, add_date, day_year, day_month, day_day, agent_id, hall_id, user_id, user_name, win_count_last, win_count_cur, totallosenums) VALUES(BetScore,BetCount,WinScore,ymd,YEAR(ymd),MONTH(ymd),DAY(ymd),AgentID,HallID,UserID,Account,0,0,1) ON DUPLICATE KEY UPDATE total_bet_score = total_bet_score + BetScore, total_bet_count = total_bet_count + BetCount, total_win_score = total_win_score + WinScore, win_count_cur = 0,totallosenums = totallosenums + 1;
END IF;
END;

