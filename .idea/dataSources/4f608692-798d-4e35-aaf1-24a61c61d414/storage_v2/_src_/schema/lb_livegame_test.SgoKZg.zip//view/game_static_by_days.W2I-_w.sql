create view game_static_by_days as
  select
    `tt`.`game_name`                   AS `游戏名称`,
    ifnull(`t`.`total_bet_score`, 0)   AS `总投注`,
    ifnull(`t`.`total_win_score`, 0)   AS `总派彩`,
    ifnull(`t`.`total_bet_count`, 0)   AS `注单数`,
    ifnull(`t`.`active_user_count`, 0) AS `玩家活跃数`,
    `t`.`add_date`                     AS `创建日期`
  from `lb_livegame_test`.`statis_game` `t`
    join `lb_livegame_test`.`game_info` `tt`
  where ((`t`.`game_id` = `tt`.`id`) and (`t`.`add_date` = cast((now() + interval -(1) day) as date)));

